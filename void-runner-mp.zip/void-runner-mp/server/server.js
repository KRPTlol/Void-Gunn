const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

app.use(express.static(path.join(__dirname, '..', 'public')));

// ---- Match constants (server is the source of truth for these) ----
const MAX_HEALTH = 100;
const HIT_DAMAGE = 28;          // fixed damage per confirmed hit, ignores client-sent values
const RESPAWN_DELAY_MS = 3000;
const MAX_SHOT_RANGE = 70;      // sanity check against obviously-impossible shots

const SPAWN_POINTS = [
  { x: 8, y: 1.7, z: 8 }, { x: -8, y: 1.7, z: 8 },
  { x: 8, y: 1.7, z: -8 }, { x: -8, y: 1.7, z: -8 },
  { x: 0, y: 1.7, z: 14 }, { x: 0, y: 1.7, z: -14 },
  { x: 14, y: 1.7, z: 0 }, { x: -14, y: 1.7, z: 0 },
];

function randomSpawn() {
  return SPAWN_POINTS[Math.floor(Math.random() * SPAWN_POINTS.length)];
}

// players keyed by socket.id
const players = new Map();

function publicPlayer(p) {
  return {
    id: p.id, name: p.name,
    x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch,
    health: p.health, alive: p.alive,
    kills: p.kills, deaths: p.deaths,
  };
}

io.on('connection', (socket) => {
  socket.on('join', (data) => {
    const name = (data && data.name ? String(data.name) : 'Runner').slice(0, 16);
    const spawn = randomSpawn();

    const player = {
      id: socket.id, name,
      x: spawn.x, y: spawn.y, z: spawn.z,
      yaw: 0, pitch: 0,
      health: MAX_HEALTH, alive: true,
      kills: 0, deaths: 0,
      lastShot: 0,
    };
    players.set(socket.id, player);

    socket.emit('init', {
      id: socket.id,
      you: publicPlayer(player),
      players: Array.from(players.values()).map(publicPlayer),
    });

    socket.broadcast.emit('playerJoined', publicPlayer(player));
  });

  // client sends its own transform frequently; server relays to everyone else
  socket.on('state', (s) => {
    const p = players.get(socket.id);
    if (!p || !p.alive) return;
    if (typeof s.x !== 'number' || typeof s.z !== 'number') return;

    p.x = s.x; p.y = s.y; p.z = s.z;
    p.yaw = s.yaw || 0; p.pitch = s.pitch || 0;

    socket.broadcast.emit('playerState', {
      id: socket.id, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch,
    });
  });

  // visual-only tracer relay (no damage applied here)
  socket.on('shoot', (s) => {
    const p = players.get(socket.id);
    if (!p || !p.alive) return;
    socket.broadcast.emit('tracer', {
      id: socket.id,
      ox: s.ox, oy: s.oy, oz: s.oz,
      dx: s.dx, dy: s.dy, dz: s.dz,
    });
  });

  // client reports a hit it detected locally; server validates and applies damage
  socket.on('hit', (s) => {
    const shooter = players.get(socket.id);
    const target = players.get(s.targetId);
    if (!shooter || !shooter.alive) return;
    if (!target || !target.alive) return;
    if (target.id === shooter.id) return;

    const dx = target.x - shooter.x, dz = target.z - shooter.z;
    const dist = Math.sqrt(dx * dx + dz * dz);
    if (dist > MAX_SHOT_RANGE) return; // reject implausible long-range claims

    const now = Date.now();
    if (now - shooter.lastShot < 90) return; // basic fire-rate sanity cap
    shooter.lastShot = now;

    target.health = Math.max(0, target.health - HIT_DAMAGE);
    io.emit('healthUpdate', { id: target.id, health: target.health });

    if (target.health <= 0) {
      target.alive = false;
      target.deaths += 1;
      shooter.kills += 1;

      io.emit('kill', {
        killerId: shooter.id, killerName: shooter.name,
        targetId: target.id, targetName: target.name,
        killerKills: shooter.kills, targetDeaths: target.deaths,
      });

      setTimeout(() => {
        if (!players.has(target.id)) return; // disconnected during delay
        const spawn = randomSpawn();
        target.x = spawn.x; target.y = spawn.y; target.z = spawn.z;
        target.health = MAX_HEALTH; target.alive = true;
        io.emit('respawn', publicPlayer(target));
      }, RESPAWN_DELAY_MS);
    }
  });

  socket.on('disconnect', () => {
    if (players.has(socket.id)) {
      players.delete(socket.id);
      io.emit('playerLeft', { id: socket.id });
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Void Runner MP server listening on :${PORT}`);
});
